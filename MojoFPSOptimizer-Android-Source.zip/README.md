# Mojo FPS Optimizer (Android companion)

A small, honest Android helper for MojoLauncher. It includes:
- Quick, safe Minecraft graphics-setting guidance.
- A button to launch compatible launcher package names if installed.
- Optional floating helper overlay (requires Android's “Display over other apps” permission).
- A link to the FrameWalk Mobile modpack page.

## Important limitations
This app does **not** overclock the GPU, modify MojoLauncher files, kill other apps, or guarantee a particular FPS. Those actions are restricted or not possible for an ordinary non-root Android app. Actual in-game gains come from compatible performance mods and lower graphics workload.

## Build without a PC
1. On your phone, create/sign in to a GitHub account.
2. Create a new repository.
3. Upload the contents of this ZIP to the repository (keep the `.github/workflows/build-apk.yml` path).
4. Open the repository's **Actions** tab and run **Build Mojo FPS Optimizer APK**.
5. When the run finishes, open its summary and download the `MojoFPSOptimizer-debug-apk` artifact.
6. Extract the artifact ZIP and install `app-debug.apk`. Android may ask permission to install apps from your browser/file manager.

GitHub's interface may vary on mobile. This workflow builds a debug APK; it is not Play Store signed.

## Build locally
Requires Android SDK, JDK 17, and Gradle 8.7:
`gradle assembleDebug`
