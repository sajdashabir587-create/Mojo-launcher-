package com.mojofps.optimizer

import android.app.Activity
import android.content.Intent
import android.net.Uri
import android.os.Bundle
import android.provider.Settings
import android.graphics.Color
import android.view.Gravity
import android.view.View
import android.widget.Button
import android.widget.LinearLayout
import android.widget.ScrollView
import android.widget.TextView
import android.widget.Toast

class MainActivity : Activity() {
    private fun dp(v: Int): Int = (v * resources.displayMetrics.density).toInt()

    override fun onCreate(savedInstanceState: Bundle?) {
        super.onCreate(savedInstanceState)
        val scroll = ScrollView(this)
        val layout = LinearLayout(this).apply {
            orientation = LinearLayout.VERTICAL
            setPadding(dp(20), dp(24), dp(20), dp(24))
            setBackgroundColor(Color.rgb(12, 19, 35))
        }
        scroll.addView(layout)

        fun text(value: String, size: Float, color: Int = Color.WHITE, bold: Boolean = false) {
            layout.addView(TextView(this).apply {
                text = value
                textSize = size
                setTextColor(color)
                if (bold) setTypeface(null, android.graphics.Typeface.BOLD)
                setPadding(0, dp(8), 0, dp(8))
            })
        }
        fun button(label: String, action: () -> Unit) {
            layout.addView(Button(this).apply {
                text = label
                isAllCaps = false
                setOnClickListener { action() }
            }, LinearLayout.LayoutParams(-1, -2).apply { topMargin = dp(6); bottomMargin = dp(4) })
        }

        text("MOJO FPS OPTIMIZER", 24f, Color.rgb(105, 190, 255), true)
        text("A real helper for MojoLauncher — no fake FPS claims.", 15f, Color.LTGRAY)
        text("QUICK SETUP", 18f, Color.WHITE, true)
        text("• Back up your Minecraft worlds first.\n• Start with 6 chunks render distance and 4 chunks simulation distance.\n• Turn shaders off, use Fast graphics, clouds off and minimal particles.\n• If available, lower resolution scaling gradually.\n• Test FPS in the same world and location.", 15f)
        text("These settings can reduce workload, but FPS depends on your phone, version, renderer and mods.", 13f, Color.rgb(255, 210, 120))
        text("BUTTONS", 18f, Color.WHITE, true)

        button("Open MojoLauncher") { launchMojo() }
        button("Enable floating gaming helper") {
            if (Settings.canDrawOverlays(this)) {
                startService(Intent(this, OverlayService::class.java))
                Toast.makeText(this, "Floating helper started", Toast.LENGTH_SHORT).show()
            } else {
                startActivity(Intent(Settings.ACTION_MANAGE_OVERLAY_PERMISSION,
                    Uri.parse("package:$packageName")))
            }
        }
        button("Open FrameWalk Mobile modpack page") {
            openUrl("https://modrinth.com/project/GB9247QD")
        }
        button("Open Android display settings") {
            startActivity(Intent(Settings.ACTION_DISPLAY_SETTINGS))
        }
        text("HONEST LIMITS", 18f, Color.WHITE, true)
        text("Android does not let a normal app overclock the GPU or force Minecraft to render faster. The floating helper gives quick tips; it does not change the game's graphics automatically.", 14f, Color.LTGRAY)
        setContentView(scroll)
    }

    private fun launchMojo() {
        val candidates = listOf(
            "net.kdt.pojavlaunch",
            "net.kdt.pojavlaunch.debug",
            "com.movtery.zalithlauncher",
            "com.mojang.minecraftpe"
        )
        for (pkg in candidates) {
            val intent = packageManager.getLaunchIntentForPackage(pkg)
            if (intent != null) {
                startActivity(intent)
                return
            }
        }
        Toast.makeText(this, "Couldn't find MojoLauncher automatically. Open it from your app list.", Toast.LENGTH_LONG).show()
    }

    private fun openUrl(url: String) {
        startActivity(Intent(Intent.ACTION_VIEW, Uri.parse(url)))
    }
}
